<template>

<h1 style="text-align: center">微博热榜</h1>
  <div class="infinite-list-wrapper" style="overflow: auto">
    <ul  v-infinite-scroll="load"  :infinite-scroll-immediate="false" >
      <el-space direction="vertical"   v-for="i in count" :key="i">
      <el-card class="zhcard" :body-style="{ width:'800px',height:'60px' }" @click="gotoZhihu">
        <div  class="tagtest"><el-tag :size="20">{{i}}</el-tag></div>
          <div class = "title">{{ zhihu_data.title }}</div>
            <p class="hot">{{ zhihu_data.hot }}</p>
          <div class="zh_img">
        <el-image :src="zhihu_data.img_url" :fit="contain" />
          </div>
      </el-card>
      </el-space>
    </ul>
    <p v-if="loading">Loading...</p>
    <p v-if="noMore">No more</p>
  </div> -->

   <el-icon id="ArrowRight" :size="90"><arrow-right-bold /></el-icon>
  <el-icon id="ArrowLeft" :size="90"><arrow-left-bold /></el-icon>
  </template>

<script lang="ts" setup>
import { el } from 'element-plus/lib/locale'
import { ArrowRightBold } from '@element-plus/icons'
import { ArrowLeftBold } from '@element-plus/icons'
import { computed, ref } from 'vue'
const count = ref(20)
const loading = ref(false)
const kong=true
const noMore = computed(() => count.value >= 36)
const load = () => {
  if(count.value<32)
  {
  loading.value = true
  setTimeout(() => {
    count.value += 2
    loading.value = false
  }, 100)
}
else
{
  loading.value = false;
}

}
// const load = () => {
//   count.value += 2
// }

</script>
<script lang="ts">
import { useRouter } from "vue-router";
export default 
{
  data(){
    return{
      
      url:"https://www.baidu.com",
      zhihu_data:
      {'hot': '2508 万',
 'img_url': 'https://pica.zhimg.com/80/v2-2ea663d8f92fb97cd2d63d7850063376_720w.jpg?source=1940ef5c',
 'rank': '1',
 'title': '怎样看待吉林农业科技学院发生的疫情以及校领导被免职？',
 'title_url': 'https://www.zhihu.com/question/521166378'}
    }
  },
  
  methods:{
    gotoZhihu(){
      window.location.href = this.zhihu_data.title_url;
    },
  }
};
</script>

<style>
.el-carousel__item h3 {
  color: #475669;
  font-size: 14px;
  opacity: 0.75;
  line-height: 150px;
  margin: 0;
  text-align: center;
}

.el-carousel__item:nth-child(2n) {
  background-color: #99a9bf;
}

.el-carousel__item:nth-child(2n + 1) {
  background-color: #d3dce6;
}

<!-- #car_test
{
  width: 100%;
  height: 1080px;
} -->



#ArrowRight{
  position: fixed;
  top:40%;
  right: 20px;
}

#ArrowLeft{
  position: fixed;
  top:40%;
  left: 20px;
}

.zhcard{
  position: relative;
  left: 0%;
}
.zh_img{  
  position: absolute;
  right: 20px;
  top:10px;
  width:150px;
  height: 80px;
  border: 2px solid green;
}
.tagtest{
  position: absolute;
  left: 0px;
  display:inline;
  border: 2px solid red;
  margin:0 8px;

    /* margin-top: 13px; */
  /* line-height: 12px; */
}
.title{
  position: absolute;
  left: 50px;
  width:450px;
  display:inline;
  border: 2px solid black;
  margin:0 8px;
  text-align: left;
}
.hot {
  position: absolute;
  left: 20px;
  bottom: 10px;
  font-size: 13px;
  color: #999;
  display:inline;
  border: 2px solid yellow;
}

.bottom {
  position: absolute;

  margin-top: 13px;
  line-height: 12px;
  width: 550px;
  height:12px;
  /* display: flex; */
  /* justify-content: space-between;
  align-items: center; */
  border: 2px solid red;
}

.button {
  padding: 0;
  min-height: auto;
}

.image {
  width: 100%;
  display: block;
}


/*  */
.infinite-list-wrapper {
  height: 800px;
  width: 1100px;
  text-align: center;
  position: relative;
  left:20%;
}
.infinite-list-wrapper .list {
  padding: 0;
  margin: 0;
  list-style: none;
}
/* 滚动条 */
.infinite-list-wrapper::-webkit-scrollbar { width: 0 !important }

.infinite-list-wrapper .list-item {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 50px;
  background: var(--el-color-danger-light-9);
  color: var(--el-color-danger);
}
.infinite-list-wrapper .list-item + .list-item {
  margin-top: 10px;
}
</style>


    <!-- <el-carousel trigger="click" height="790px" indicator-position="outside" :autoplay=false>
      <el-carousel-item v-for="item in 3" :key="item">
        <h3 class="small" v-if="item!=1">{{ item }}</h3>
        <h1 style="text-align: center" v-if="item==1">知乎热榜</h1>
  <div class="infinite-list-wrapper" style="overflow: auto" v-if="item==1">
    <ul  v-infinite-scroll="load"  :infinite-scroll-immediate="false" >
      <el-space direction="vertical"   v-for="i in count" :key="i">
      <el-card class="zhcard" :body-style="{ width:'800px',height:'60px' }" @click="gotoZhihu">
        <div  class="tagtest"><el-tag :size="20">{{i}}</el-tag></div>
          <div class = "title">{{ zhihu_data.title }}</div>
            <p class="hot">{{ zhihu_data.hot }}</p>
          <div class="zh_img">
        <el-image :src="zhihu_data.img_url" :fit="contain" />
          </div>
      </el-card>
      </el-space>
    </ul>
    <p v-if="loading">Loading...</p>
    <p v-if="noMore">No more</p>
  </div>
      </el-carousel-item>
    </el-carousel> -->